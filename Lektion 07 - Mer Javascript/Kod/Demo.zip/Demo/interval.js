function newSecond()
{
    var d = new Date();
    var sekund = d.getSeconds();
    document.getElementById('sekund').innerHTML = sekund;
}